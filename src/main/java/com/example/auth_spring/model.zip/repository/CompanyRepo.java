package com.example.auth_spring.repository;

import com.example.auth_spring.model.Company;
import com.example.auth_spring.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Set;

public interface CompanyRepo extends JpaRepository<Company, Integer> {
    List<Company> findByCreatedBy(User user); // Компании, созданные конкретным пользователем
    Set<Company> findByNameContainingIgnoreCase(String substring); // Компании, созданные конкретным пользователем
    Set<Company> findByDescriptionContainingIgnoreCase(String substring); // Компании, созданные конкретным пользователем
}