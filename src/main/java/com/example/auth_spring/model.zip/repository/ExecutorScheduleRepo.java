package com.example.auth_spring.repository;


import com.example.auth_spring.model.ExecutorSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ExecutorScheduleRepo extends JpaRepository<ExecutorSchedule, Integer> {
    List<ExecutorSchedule> findByExecutorId(Integer executorId); // Расписание конкретного исполнителя
}
