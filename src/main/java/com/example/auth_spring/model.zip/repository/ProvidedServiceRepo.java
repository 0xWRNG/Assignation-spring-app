package com.example.auth_spring.repository;


import com.example.auth_spring.model.ProvidedService;
import io.micrometer.common.lang.NonNull;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ProvidedServiceRepo extends JpaRepository<ProvidedService, Integer> {
    List<ProvidedService> findByCompanyId(Integer companyId);
    List<ProvidedService> findByTitleContainingIgnoreCase(String substring);
    List<ProvidedService> findByDescriptionContainingIgnoreCase(String substring);

    Optional<ProvidedService> findById(@NonNull Integer serviceId);
}
