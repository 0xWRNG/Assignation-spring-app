package com.example.auth_spring.repository;


import com.example.auth_spring.model.Company;
import com.example.auth_spring.model.ManagerToCompany;
import com.example.auth_spring.model.User;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;

public interface ManagerToCompanyRepo extends JpaRepository<ManagerToCompany, Integer> {
    List<ManagerToCompany> findByCompany(Company company);
    List<ManagerToCompany> findByManager(User manager);
}
