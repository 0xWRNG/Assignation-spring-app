package com.example.auth_spring.repository;


import com.example.auth_spring.model.BookedTimeslot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookedTimeslotRepo extends JpaRepository<BookedTimeslot, Integer> {
    List<BookedTimeslot> findByExecutorToServiceId(Integer executorToServiceId); // Таймслоты для определённой услуги
    List<BookedTimeslot> findByUserId(Integer userId); // Таймслоты, забронированные пользователем

//    List<BookedTimeslot> findByExecutorId(Integer executorId);
}
