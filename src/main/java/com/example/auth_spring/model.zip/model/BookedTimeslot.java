package com.example.auth_spring.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "booked_timeslots")
public class BookedTimeslot {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "executor_to_serv_id", nullable = false)
    private ExecutorToService executorToService;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column
    private LocalDateTime timeBegin;
    @Column
    private LocalDateTime timeEnd;

//    public Integer getId(){return id;}
}
