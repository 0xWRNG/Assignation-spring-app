package com.example.auth_spring.model;


import com.example.auth_spring.model.enums.Repeat;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
@Data
@Entity
@Table(name = "executor_schedules")
public class ExecutorSchedule {
    @Id
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "executor_id", nullable = false)
    private Executor executor;

    @Column
    private LocalDateTime timeBegin;

    @Column
    private LocalDateTime timeEnd;

    @Column
    @Enumerated(EnumType.STRING)
    private Repeat repeatable;


}
