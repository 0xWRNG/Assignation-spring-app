package com.example.auth_spring.model.enums;

public enum Role {
    ADMIN, MANAGER, USER
}
