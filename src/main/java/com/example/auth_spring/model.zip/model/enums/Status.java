package com.example.auth_spring.model.enums;

public enum Status {
    APPROVED, NOT_APPROVED, CANCELLED;
}
