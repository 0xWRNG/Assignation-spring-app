package com.example.auth_spring.model.enums;

public enum Repeat {
    NONE, DAILY, WEEKLY, MONTHLY
}