package com.example.auth_spring.model;


import com.example.auth_spring.model.enums.Role;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Setter;

import java.util.Objects;

@Data
@Entity
@Table(name = "managers_to_company")
public class ManagerToCompany {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Setter
    @ManyToOne
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @ManyToOne
    @JoinColumn(name = "manager_id", nullable = false)
    private User manager;

    public void setManager(User manager) {
        if(manager == null || !Objects.equals(manager.getRole(), Role.MANAGER.toString()))
            return;

    }

}
