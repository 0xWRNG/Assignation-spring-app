package com.example.auth_spring.controller;


import com.example.auth_spring.model.Company;
import com.example.auth_spring.model.Executor;
import com.example.auth_spring.model.ProvidedService;
import com.example.auth_spring.service.CompanyService;
import com.example.auth_spring.service.ExecutorService;
import com.example.auth_spring.service.ServiceManagementService;
import org.springframework.ui.Model;
import com.example.auth_spring.model.User;
import com.example.auth_spring.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Controller
@RequestMapping("/")
public class MainpageController {
    @Autowired
    private UserService userService;
    private User currentUser;

    @Autowired
    private ServiceManagementService serviceManagementService;
    @Autowired
    private ExecutorService executorService;
    @Autowired
    private CompanyService companyService;





    @GetMapping("/")
    public String index(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        if(userDetails==null) {
            currentUser.setRole("USER");
            currentUser.setLogin("NOT_AUTHENTICATED");
        }else{
            currentUser = userService.getUserByLogin(userDetails.getUsername());
            model.addAttribute("user", currentUser);
        }

        return "mainpage";
    }

    @PostMapping("")
    public String search(@AuthenticationPrincipal UserDetails userDetails, Model model, @RequestParam String request, @RequestParam String type) {
        if(Objects.equals(currentUser.getRole(), "MANAGER")) {

        }else{

            model.addAttribute("request", request);
            model.addAttribute("type", type);
            switch(type) {
                case "serviceName":
                    List<ProvidedService> serviceList = serviceManagementService.findBySubstringInTitle(request);
                    model.addAttribute("services", serviceList);
                    break;
                case "serviceDescription":
                    serviceList =serviceManagementService.findBySubstringInDescription(request);
                    model.addAttribute("services", serviceList);

                    break;
                case "companyName":
                    List<Company> companies = companyService.findBySubstring(request);
                    model.addAttribute("companies", companies);
                    break;
                case "executor":
                    List<Executor> executors = executorService.findBySubstring(request);
                    model.addAttribute("executors", executors);
                    break;

                default:
                    break;
            }
        }
        model.addAttribute("user", currentUser);
        return "mainpage";
    }
}
