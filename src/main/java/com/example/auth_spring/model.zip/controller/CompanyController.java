package com.example.auth_spring.controller;

import com.example.auth_spring.model.*;
import com.example.auth_spring.model.enums.*;
import com.example.auth_spring.service.CompanyService;
import com.example.auth_spring.service.ExecutorService;
import com.example.auth_spring.service.ServiceManagementService;
import com.example.auth_spring.service.UserService;
import com.example.auth_spring.utils.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Controller
@RequestMapping("/company")

public class CompanyController {

    @Autowired
    private CompanyService companyService;
    @Autowired
    private ServiceManagementService serviceManagementService;
    @Autowired
    private ExecutorService executorService;
    @Autowired
    private UserService userService;

    @GetMapping("/{id}")
    public String showCompany(@PathVariable Integer id, Model model, @AuthenticationPrincipal UserDetails userDetails) {
        String username = userDetails.getUsername();
        User user = userService.getUserByLogin(username);
        Optional<Company> company = companyService.findById(id);
        if (company.isPresent()) {
            model.addAttribute("role", user.getRole());
            List<ProvidedService> services = serviceManagementService.findServicesByCompany(id);
            List<Pair<Executor, Integer>> executors = executorService.findExecutorsByCompany(id);
            model.addAttribute("company", company.get());
            model.addAttribute("services", services);
            model.addAttribute("executors", executors);
        }
        return "company";
    }

    @PostMapping("/{id}/edit")
    public String editCompany(@PathVariable Integer id, Model model, @AuthenticationPrincipal UserDetails userDetails,
                              @RequestParam String name,
                              @RequestParam String description,
                              @RequestParam String home_url,
                              @RequestParam String phone,
                              @RequestParam String email)

    {
        User user = userService.getUserByLogin(userDetails.getUsername());
        if (Objects.equals(user.getRole(), Role.MANAGER.toString())& companyService.findById(id).isPresent()) {
            Company company = companyService.findById(id).get();
            company.setName(name);
            company.setDescription(description);
            company.setHome_url(home_url);
            company.setPhone(phone);
            company.setEmail(email);
            companyService.updateCompany(company);
        }

        return "redirect:/company/" + id;
    }

}
