package com.example.auth_spring.controller;

import com.example.auth_spring.model.BookedTimeslot;
import com.example.auth_spring.model.Company;
import com.example.auth_spring.model.User;
import com.example.auth_spring.service.BookedTimeslotsService;
import com.example.auth_spring.service.CustomUserDetailsService;
import com.example.auth_spring.service.ManagerToCompanyService;
import com.example.auth_spring.service.UserService;
import com.example.auth_spring.utils.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/profile")
public class ProfileController {

    @Autowired
    private UserService userService;

    private final BookedTimeslotsService bookedTimeslotsService;
    private final ManagerToCompanyService managerToCompanyService;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    public ProfileController(BookedTimeslotsService bookedTimeslotsService, ManagerToCompanyService managerToCompanyService) {
        this.bookedTimeslotsService = bookedTimeslotsService;
        this.managerToCompanyService = managerToCompanyService;
    }


    @GetMapping("")
    public String showProfile(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user;
        if (userDetails == null) {
            return "redirect:/login";
        }

        String username = userDetails.getUsername();
        user = userService.getUserByLogin(username);
        switch (user.getRole()) {
            case "USER":
                List<BookedTimeslot> userTimeslots = bookedTimeslotsService.findByUser(user.getId());
                model.addAttribute("services", userTimeslots);
            case "MANAGER":
                List<Pair<Company, List<User>>> managedCompanies = managerToCompanyService.getCompanyWithRelatedManagers(user);

                model.addAttribute("companies", managedCompanies);
        }


        Class<?> clazz = user.getClass();
        Field[] fields = clazz.getDeclaredFields();


        for (Field field : fields) {
            field.setAccessible(true);
            try {
                Object value = field.get(user);
                model.addAttribute(field.getName(), value);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return "profile"; // Страница профиля
    }

    @GetMapping("edit")
    public String showEditProfile(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user;
        if (userDetails == null) {
            return "redirect:/login";
        }
        String username = userDetails.getUsername();
        user = userService.getUserByLogin(username);

        model.addAttribute("edit", true);
        switch (user.getRole()) {
            case "USER":
                List<BookedTimeslot> userTimeslots = bookedTimeslotsService.findByUser(user.getId());
                model.addAttribute("services", userTimeslots);
            case "MANAGER":
                List<Pair<Company, List<User>>> managedCompanies = managerToCompanyService.getCompanyWithRelatedManagers(user);

                model.addAttribute("companies", managedCompanies);
        }


        Class<?> clazz = user.getClass();
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            try {
                Object value = field.get(user);
                model.addAttribute(field.getName(), value);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return "profile"; // Страница профиля
    }

    @PostMapping("edit")
    public String editProfile(@AuthenticationPrincipal UserDetails userDetails, Model model,
                              @RequestParam String surname,
                              @RequestParam String name,
                              @RequestParam String patronymic,
                              @RequestParam String email,
                              @RequestParam String phone
    ) {
        if (userDetails == null) {
            return "redirect:/login";
        }
        String username = userDetails.getUsername();
        User user = userService.getUserByLogin(username);

        user.setSurname(surname);
        user.setName(name);
        user.setPatronymic(patronymic);
        user.setEmail(email);
        user.setPhone(phone);

        userService.saveUser(user);
        return "redirect:/profile";

    }

}
/*TODO
*Validation while editing
 */