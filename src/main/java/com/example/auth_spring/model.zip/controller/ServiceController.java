package com.example.auth_spring.controller;

import com.example.auth_spring.model.Company;
import com.example.auth_spring.model.Executor;
import com.example.auth_spring.model.ProvidedService;
import com.example.auth_spring.model.User;
import com.example.auth_spring.model.enums.*;
import com.example.auth_spring.service.CompanyService;
import com.example.auth_spring.service.ExecutorService;
import com.example.auth_spring.service.ServiceManagementService;
import com.example.auth_spring.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/service")
public class ServiceController {
    @Autowired
    private UserService userService;
    @Autowired
    private ServiceManagementService serviceManagementService;
    @Autowired
    private CompanyService companyService;
    @Autowired
    private ExecutorService executorService;

    @GetMapping("add/{id}")
    public String add_get_Service(@AuthenticationPrincipal UserDetails userDetails, Model model, @PathVariable Integer id) {
        User user = userService.getUserByLogin(userDetails.getUsername());
        model.addAttribute("user", user);
        Optional<ProvidedService> currentServiceservice = serviceManagementService.findById(id);
        currentServiceservice.ifPresent(providedService -> model.addAttribute("service", providedService));
        List<Executor> executors = executorService.findByService(id);
        model.addAttribute("executors", executors);
        model.addAttribute("mode", "add");
        return "service";
    }
    @GetMapping("{id}")
    public String showService(@AuthenticationPrincipal UserDetails userDetails, Model model, @PathVariable Integer id) {
        User user = userService.getUserByLogin(userDetails.getUsername());
        model.addAttribute("user", user);
        Optional<ProvidedService> currentServiceservice = serviceManagementService.findById(id);
        currentServiceservice.ifPresent(providedService -> model.addAttribute("service", providedService));
        List<Executor> executors = executorService.findByService(id);
        model.addAttribute("executors", executors);

        model.addAttribute("mode", "show");
        return "service";
    }

    @PostMapping("add/{id}")
    public String add_post_Service(@AuthenticationPrincipal UserDetails userDetails, Model model, @PathVariable Integer id, @ModelAttribute ProvidedService providedService) {
        User user = userService.getUserByLogin(userDetails.getUsername());
        model.addAttribute("user", user);
        if(user.getRole()!= Role.MANAGER.toString()){
            return "redirect:/";
        }
        if (id==null) {
            return "redirect:/";
        }
        ProvidedService providedService_toSave = new ProvidedService();
        Optional<Company> company_opt = companyService.findById(id);
        if (company_opt.isPresent()) {
            Company company = company_opt.get();
            providedService_toSave.setCompany(company);
        }
        Class<?> clazz = providedService_toSave.getClass();
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            if(field.getName()=="id"){
                continue;
            }
            field.setAccessible(true);
            try {
                Object value = field.get(providedService);
                if (value != null) {
                    field.set(providedService_toSave, value);
                }
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
        serviceManagementService.saveService(providedService_toSave);

        return "redirect:/service/" + providedService.getId();
    }
}
