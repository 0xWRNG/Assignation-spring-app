package com.example.auth_spring.controller;

import com.example.auth_spring.model.*;
import com.example.auth_spring.model.enums.*;
import com.example.auth_spring.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Controller
@RequestMapping("/executor")
public class ExecutorController {
    @Autowired
    private ExecutorService executorService;
    @Autowired
    private ManagerToCompanyService managerToCompanyService;
    @Autowired
    private UserService userService;
    @Autowired
    private ServiceManagementService serviceManagementService;
    @Autowired
    private CompanyService companyService;


    @GetMapping("/{id}")
    public String showProfile(@AuthenticationPrincipal UserDetails userDetails, @PathVariable Integer id, Model model) {
        Optional<Executor> exec = executorService.findById(id);
        if (exec.isEmpty()) {
            return "redirect:/";
        }
        List<ProvidedService> services = executorService.findExecutorsProvidedService(id);
        model.addAttribute("executor", exec.get());
        model.addAttribute("services", services);

        User user = userService.getUserByLogin(userDetails.getUsername());
        model.addAttribute("user", user);

        return "executor_profile";
    }

    @GetMapping("/{id}/edit")
    public String editProfile(@AuthenticationPrincipal UserDetails userDetails, @PathVariable Integer id, Model model) {
        Optional<Executor> exec = executorService.findById(id);
        User user = userService.getUserByLogin(userDetails.getUsername());
        model.addAttribute("user", user);
        if (exec.isEmpty() || !Objects.equals(user.getRole(), Role.MANAGER.toString())) {
            return "redirect:/";
        }
        if (!managerToCompanyService.isManagerInCompany(user, exec.get().getCompany())) {
            return "redirect:/";
        }
        List<ProvidedService> services = executorService.findExecutorsProvidedService(id);
        model.addAttribute("executor", exec.get());
        model.addAttribute("services", services);
        model.addAttribute("user", user);
        model.addAttribute("edit", true);

        return "executor_profile";
    }

    @GetMapping("/{id}/add")
    public String addExecutor(@AuthenticationPrincipal UserDetails userDetails, @PathVariable Integer id, Model model) {
        User user = userService.getUserByLogin(userDetails.getUsername());
        if(!user.getRole().equals(Role.MANAGER.toString())) {
            return "redirect:/";
        }
        List<ProvidedService> services =  serviceManagementService.findServicesByCompany(id);
        model.addAttribute("services", services);
        return "executor_add";
    }
    @PostMapping("/{company_id}/add")
    public String add(@AuthenticationPrincipal UserDetails userDetails, @PathVariable Integer company_id, @ModelAttribute  Executor executor, @RequestParam(value = "services", required = false) List<String> services) {
        User user = userService.getUserByLogin(userDetails.getUsername());
        if(!user.getRole().equals(Role.MANAGER.toString())) {
            return "redirect:/";
        }
        Executor executorToSave = new Executor();
        Class<?> clazz = executorToSave.getClass();
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            try {
                Object value = field.get(executor);
                if (value != null) {
                    field.set(executorToSave, value);
                }
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
        Optional<Company> comp_opt =  companyService.findById(company_id);
        if (!comp_opt.isPresent()) {
            return "redirect:/";
        }
        Company comp = comp_opt.get();
        executorToSave.setCompany(comp);
        executorService.saveExecutor(executorToSave);
        if(services!=null){
            for(String service_id: services) {
                executorService.assignServiceById(executorToSave, Integer.parseInt(service_id));
            }
        }
        return "redirect:/company/" + company_id;
    }

    @PostMapping("{id}/edit")
    public String edit(@AuthenticationPrincipal UserDetails userDetails, @PathVariable Integer id, @ModelAttribute Executor executor) {
        Optional<Executor> get_executor = executorService.findById(id);
        User user = userService.getUserByLogin(userDetails.getUsername());
        if (get_executor.isEmpty() || !user.getRole().equals(Role.MANAGER.toString())) {
            return "redirect:/";
        }

        Executor executor_not_updated = get_executor.get();
        Class<?> clazz = executor_not_updated.getClass();
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            try {
                Object value = field.get(executor);
                if (value == null) {
                    continue;
                }
                field.set(executor_not_updated, value);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        executorService.saveExecutor(executor_not_updated);
        return "redirect:/executor/" + id;
    }

    @PostMapping("delete/{id}")
    public String deleteExecutor(@AuthenticationPrincipal UserDetails userDetails, @PathVariable Integer id) {
        Optional<Executor> get_executor = executorService.findById(id);
        User user = userService.getUserByLogin(userDetails.getUsername());
        Optional<Executor> executorToDelete = executorService.findById(id);
        Integer company_id;
        if(user.getRole().equals(Role.MANAGER.toString()) && executorToDelete.isPresent()) {
            Executor executor = executorToDelete.get();
            company_id = executor.getCompany().getId();
            executorService.deleteExecutor(id);
            return "redirect:/company/" + company_id;
        }
        return "redirect:/";
    }
}
/*TODO
 * Do schedule display
 * */