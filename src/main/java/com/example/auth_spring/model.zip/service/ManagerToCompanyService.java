package com.example.auth_spring.service;

import com.example.auth_spring.model.Company;
import com.example.auth_spring.model.ManagerToCompany;
import com.example.auth_spring.utils.*;
import com.example.auth_spring.model.User;
import com.example.auth_spring.repository.ManagerToCompanyRepo;
import org.apache.catalina.Manager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ManagerToCompanyService {
    private final ManagerToCompanyRepo repository;

    @Autowired
    public ManagerToCompanyService(ManagerToCompanyRepo repository) {
        this.repository = repository;
    }

    public void addManagerToCompany(User manager, Company company) {
        ManagerToCompany association = new ManagerToCompany();
        association.setManager(manager);
        association.setCompany(company);
        repository.save(association);
    }

    public List<ManagerToCompany> getManagersByCompany(Company company) {
        return repository.findByCompany(company);
    }

    public List<Pair<Company, List<User>>> getCompanyWithRelatedManagers(User manager) {
        List<Pair<Company, List<User>>> companyWithRelatedManagers = new ArrayList<>();

        List<ManagerToCompany> managerToCompanies = repository.findByManager(manager);

        for (ManagerToCompany managerToCompany : managerToCompanies) {
            Company company = managerToCompany.getCompany();

            // Находим всех менеджеров, связанных с этой компанией
            List<User> managers = new ArrayList<>();
            for (ManagerToCompany companyToManager : repository.findByCompany(company)) {
                managers.add(companyToManager.getManager());
            }

            // Создаем пару и добавляем в список
            Pair<Company, List<User>> pair = new Pair<>(company, managers);
            companyWithRelatedManagers.add(pair);
        }

        return companyWithRelatedManagers;
    }
    public boolean isManagerInCompany(User manager, Company company) {
        List<ManagerToCompany> managerToCompanies = repository.findByManager(manager);
        for (ManagerToCompany managerToCompany : managerToCompanies) {
            if (managerToCompany.getCompany().equals(company)) {
                return true;
            }
        }
        return false;
    }
}