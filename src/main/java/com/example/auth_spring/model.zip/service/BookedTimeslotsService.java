package com.example.auth_spring.service;

import com.example.auth_spring.model.BookedTimeslot;
import com.example.auth_spring.repository.BookedTimeslotRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookedTimeslotsService {

    @Autowired
    private final BookedTimeslotRepo bookedTimeslotsRepository;

    @Autowired
    public BookedTimeslotsService(BookedTimeslotRepo bookedTimeslotsRepository) {
        this.bookedTimeslotsRepository = bookedTimeslotsRepository;
    }


    // Забронировать таймслот
    public BookedTimeslot bookTimeslot(BookedTimeslot timeslot) {
        return bookedTimeslotsRepository.save(timeslot);
    }

    // Найти бронирования пользователя
    public List<BookedTimeslot> findByUser(Integer userId) {
        return bookedTimeslotsRepository.findByUserId(userId);
    }

//    // Найти бронирования исполнителя
//    public List<BookedTimeslot> findByExecutor(Integer executorId) {
//        return bookedTimeslotsRepository.findByExecutorId(executorId);
//    }

    // Удалить бронирование
    public void deleteTimeslot(Integer id) {
        bookedTimeslotsRepository.deleteById(id);
    }
}
