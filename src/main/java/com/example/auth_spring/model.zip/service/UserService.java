package com.example.auth_spring.service;

import com.example.auth_spring.model.User;
import com.example.auth_spring.repository.UserRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;


@RequiredArgsConstructor(onConstructor_ = {@Autowired})
@Service
public class UserService {

    @Autowired
    private UserRepo userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

//    public UserService(UserRepo userRepository, PasswordEncoder passwordEncoder) {
//        this.userRepository = userRepository;
//        this.passwordEncoder = passwordEncoder;
//    }

    public void register(User user) {
        if (userRepository.existsByLogin(user.getLogin())) {
            throw new RuntimeException("Login already exists");
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
    }

    public User getUserByLogin(String login) {
        User user = userRepository.findByLogin(login).orElseThrow(() -> new RuntimeException("Login not found"));
        return user;
    }

    public User getUserById(int id) {
        return userRepository.getReferenceById(id);
    }

    public void saveUser(User user) {
        userRepository.save(user);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public void deleteUser(int id) {
        userRepository.deleteById(id);
    }
}
