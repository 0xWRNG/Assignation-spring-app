package com.example.auth_spring.service;

import com.example.auth_spring.model.Executor;
import com.example.auth_spring.model.ExecutorToService;
import com.example.auth_spring.model.ProvidedService;
import com.example.auth_spring.repository.ExecutorRepo;
import com.example.auth_spring.repository.ExecutorScheduleRepo;
import com.example.auth_spring.repository.ExecutorToServiceRepo;
import com.example.auth_spring.repository.ProvidedServiceRepo;
import com.example.auth_spring.utils.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ExecutorService {
    private final ExecutorRepo executorRepository;
    private final ExecutorToServiceRepo executorToServiceRepo;
    private final ExecutorScheduleRepo executorScheduleRepo;
    private final ExecutorToProvidedServService executorToProvidedServService;
    private final ProvidedServiceRepo providedServiceRepo;

    @Autowired
    public ExecutorService(ExecutorRepo executorRepository, ExecutorToServiceRepo executorServiceRepository, ExecutorScheduleRepo executorScheduleRepo, ExecutorToProvidedServService executorToProvidedServService, ProvidedServiceRepo providedServiceRepo) {
        this.executorRepository = executorRepository;
        this.executorToServiceRepo = executorServiceRepository;
        this.executorScheduleRepo = executorScheduleRepo;
        this.executorToProvidedServService = executorToProvidedServService;
        this.providedServiceRepo = providedServiceRepo;
    }

    public Executor saveExecutor(Executor executor) {
        return executorRepository.save(executor);
    }

    public List<Pair<Executor, Integer>> findExecutorsByCompany(Integer companyId) {
        List<Pair<Executor, Integer>> executorsWithServiceCount = new ArrayList<>();
        List<Executor> execs = executorRepository.findByCompanyId(companyId);
        for (Executor exec : execs) {
            Pair<Executor, Integer> pair = new Pair<>(exec, executorToServiceRepo.findByExecutorId(exec.getId()).size());
            executorsWithServiceCount.add(pair) ;
        }
        return executorsWithServiceCount;
    }
    public List<ProvidedService> findExecutorsProvidedService(Integer executorId) {
        List<ExecutorToService> execWithServ = executorToServiceRepo.findByExecutorId(executorId);
        List<ProvidedService> providedServices = new ArrayList<>();
        for (ExecutorToService exec : execWithServ) {
            providedServices.add(exec.getProvidedService());
        }
        return providedServices;
    }


    public Optional<Executor> findById(Integer id) {
        return executorRepository.findById(id);
    }

    public void deleteExecutor(Integer id) {
        executorRepository.deleteById(id);
    }

    public List<Executor> findBySubstring(String substring) {
        if (substring == null || substring.trim().isEmpty()) {
            return List.of();
        }
        return executorRepository.findBySubstringInAttributes(substring);
    }

    public void assignServiceById(Executor executor, Integer serviceId) {
        ExecutorToService executorToService = new ExecutorToService();
        ProvidedService providedService = providedServiceRepo.findById(serviceId).get();
        executorToService.setExecutor(executor);
        executorToService.setProvidedService(providedService);
        executorToServiceRepo.save(executorToService);
    }

    public List<Executor> findByService(Integer serviceId) {
        List<ExecutorToService> executorToServ = executorToServiceRepo.findByProvidedServiceId(serviceId);
        List<Executor> executors = new ArrayList<>();
        for (ExecutorToService exec : executorToServ) {
            executors.add(exec.getExecutor());
        }
        return executors;
    }


}
