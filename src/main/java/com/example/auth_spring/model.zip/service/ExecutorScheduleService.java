package com.example.auth_spring.service;

import com.example.auth_spring.model.ExecutorSchedule;
import com.example.auth_spring.repository.ExecutorScheduleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExecutorScheduleService {
    private final ExecutorScheduleRepo executorScheduleRepository;

    @Autowired
    public ExecutorScheduleService(ExecutorScheduleRepo executorScheduleRepository) {
        this.executorScheduleRepository = executorScheduleRepository;
    }

    // Создать расписание для исполнителя
    public ExecutorSchedule createSchedule(ExecutorSchedule schedule) {
        return executorScheduleRepository.save(schedule);
    }

    // Получить расписание исполнителя
    public List<ExecutorSchedule> findSchedulesByExecutorId(Integer executorId) {
        return executorScheduleRepository.findByExecutorId(executorId);
    }

    // Удалить расписание
    public void deleteSchedule(Integer id) {
        executorScheduleRepository.deleteById(id);
    }
}
