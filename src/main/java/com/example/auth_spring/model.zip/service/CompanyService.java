package com.example.auth_spring.service;

import com.example.auth_spring.model.Company;
import com.example.auth_spring.model.ProvidedService;
import com.example.auth_spring.model.User;
import com.example.auth_spring.repository.CompanyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CompanyService {
    private final CompanyRepo companyRepository;

    @Autowired
    public CompanyService(CompanyRepo companyRepo) {
        this.companyRepository = companyRepo;
    }


    public Optional<Company> findById(Integer id) {
        return companyRepository.findById(id);
    }

    public List<Company> getCompaniesByUser(User user) {
        return companyRepository.findByCreatedBy(user);
    }

    public Company createCompany(Company company) {
        return companyRepository.save(company);
    }
    public Company updateCompany(Company company) {
        return companyRepository.save(company);
    }
    public List<Company> findBySubstring(String substring) {
        if (substring == null || substring.trim().isEmpty()) {
            return List.of();
        }
        Set<Company> companies = new HashSet<>();
        companies.addAll(companyRepository.findByNameContainingIgnoreCase(substring));
        companies.addAll(companyRepository.findByDescriptionContainingIgnoreCase(substring));
        return new ArrayList<>(companies);
    }


}
