package com.example.auth_spring.service;

import com.example.auth_spring.model.ProvidedService;
import com.example.auth_spring.repository.ProvidedServiceRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ExecutorToProvidedServService {

}
